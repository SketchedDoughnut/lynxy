# builtins
import socket
import time
import os

def do():
    print('this works!')