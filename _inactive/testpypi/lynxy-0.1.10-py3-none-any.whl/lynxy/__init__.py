'''
This is the lynxy client module. To find documentation, go to the github~!
- Github: https://github.com/SketchedDoughnut/LYNX
'''

# extending main lynx file
from .lynx import *