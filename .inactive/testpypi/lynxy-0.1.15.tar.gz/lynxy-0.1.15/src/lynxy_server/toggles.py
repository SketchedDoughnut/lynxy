limit_username = True
overwrite_usernames = True
clear_dead_usernames = True