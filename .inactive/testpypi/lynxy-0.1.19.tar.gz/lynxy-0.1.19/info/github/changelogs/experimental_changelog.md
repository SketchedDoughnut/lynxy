[Home](https://github.com/SketchedDoughnut/lynxy) <br>
***
**This changelog was started at 6/3/24**
***
# v0.1.18
**6/4/24**
- Added the working asymmetrical encryption to server/client communications, and improved how strings are interpreted into types (dictionary, tuple, etc).
- Commit label: [9be25a4](https://github.com/SketchedDoughnut/lynxy/tree/9be25a425ff833e5490de4871f6abd8daef7861b)