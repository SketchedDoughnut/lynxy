# **lynxy**
Local (yielding?) Network (eXchange?) (the y is cosmetic)

# **Introduction**
lynxy, also known as lynx, is a LAN server-client system coded in Python. It allows for easy setup of a server, as well as easy setup for clients on the same network as the server. 
Check out the github below to learn how to use this module.
- Github: https://github.com/SketchedDoughnut/lynxy